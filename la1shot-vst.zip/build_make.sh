#!/usr/bin/env bash
# ============================================================
# 1o1 DARK SYNTH - build using the "make" (Unix Makefiles) generator
# Works on Linux and macOS. Requires CMake + a C++ toolchain (make/gcc/clang).
# This is the exact path that has been compile-verified.
# ============================================================
set -e
cd "$(dirname "$0")"

JOBS="$( (nproc 2>/dev/null) || (sysctl -n hw.ncpu 2>/dev/null) || echo 4)"

echo "==> Configuring with generator: Unix Makefiles (make)"
cmake -B build -G "Unix Makefiles" -DCMAKE_BUILD_TYPE=Release

echo "==> Building with make (-j$JOBS)..."
cmake --build build --config Release -j"$JOBS"

echo ""
echo "DONE. Built plugin(s):"
find build -name "*.vst3" -o -name "*.component" | sed 's/^/  /'
