#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class LaLookAndFeel : public juce::LookAndFeel_V4
{
public:
    LaLookAndFeel();
    void drawRotarySlider (juce::Graphics&, int, int, int, int, float, float, float, juce::Slider&) override;
    juce::Font getComboBoxFont (juce::ComboBox&) override;
};

class LA1shotEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit LA1shotEditor (LA1shotProcessor&);
    ~LA1shotEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using SliderAtt = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAtt  = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    struct Ctl { juce::Slider slider; juce::Label label; std::unique_ptr<SliderAtt> att; };

    void addKnob (const juce::String& id, const juce::String& name);
    void timerCallback() override;

    LA1shotProcessor& proc;
    juce::OwnedArray<Ctl> knobs;
    juce::ComboBox keyBox, scaleBox;
    std::unique_ptr<ComboAtt> keyAtt, scaleAtt;
    juce::Rectangle<int> rTune, rEq, rDyn, rMeter;
    float meterHz = 0.0f, meterTgt = 0.0f;
    LaLookAndFeel lnf;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (LA1shotEditor)
};
