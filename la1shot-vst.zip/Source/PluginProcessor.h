#pragma once
#include <JuceHeader.h>
#include <vector>

// LA1shot — vocal chain effect: Auto-Tune -> HPF -> EQ -> Compressor -> De-Esser -> Reverb
class LA1shotProcessor : public juce::AudioProcessor
{
public:
    LA1shotProcessor();
    ~LA1shotProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "LA1shot"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 2.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    juce::AudioProcessorValueTreeState apvts { *this, nullptr, "PARAMS", createLayout() };

    // live pitch readout for the editor meter
    std::atomic<float> detectedHz { 0.0f };
    std::atomic<float> targetHz { 0.0f };

private:
    double sr = 44100.0;

    // ---- Auto-Tune (pitch detect + granular shift) ----
    void detectPitch();
    float scaleQuantise (float hz) const;

    std::vector<float> pitchBuf;     // mono detection ring
    int pitchWrite = 0;
    int pitchBufLen = 2048;
    float smoothedRatio = 1.0f;

    // per-channel granular pitch shifter state
    struct Shifter { std::vector<float> dl; int wr = 0; float rp1 = 0, rp2 = 0; };
    Shifter shifter[2];
    int dlLen = 4096;

    // ---- Chain (juce::dsp) ----
    using Filter = juce::dsp::IIR::Filter<float>;
    using Coefs  = juce::dsp::IIR::Coefficients<float>;
    juce::dsp::ProcessorDuplicator<Filter, Coefs> hp, eqLow, eqMid, eqHigh;
    juce::dsp::Compressor<float> comp;
    juce::dsp::ProcessorDuplicator<Filter, Coefs> deEssShelf;
    juce::dsp::IIR::Filter<float> deEssDetect[2]; // sidechain highpass per channel
    float deEssEnv[2] { 0, 0 };
    juce::dsp::Reverb reverb;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (LA1shotProcessor)
};
