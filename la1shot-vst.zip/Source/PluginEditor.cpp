#include "PluginEditor.h"

// LA1shot palette — dark with teal + violet Antares vibe
static const juce::Colour kBg    { 0xff0c0e14 };
static const juce::Colour kPanel { 0xff141824 };
static const juce::Colour kEdge  { 0xff2a3350 };
static const juce::Colour kTeal  { 0xff2fe0c4 };
static const juce::Colour kViolet{ 0xff8b5cf6 };
static const juce::Colour kText  { 0xffdfe6f0 };
static const juce::Colour kMuted { 0xff7a869c };

LaLookAndFeel::LaLookAndFeel()
{
    setColour (juce::PopupMenu::backgroundColourId, kPanel);
    setColour (juce::PopupMenu::textColourId, kText);
    setColour (juce::PopupMenu::highlightedBackgroundColourId, kViolet);
}
juce::Font LaLookAndFeel::getComboBoxFont (juce::ComboBox&) { return juce::Font (juce::Font::getDefaultMonospacedFontName(), 12.5f, juce::Font::bold); }

void LaLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h,
                                      float pos, float startAngle, float endAngle, juce::Slider&)
{
    auto b = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (6.0f);
    auto radius = juce::jmin (b.getWidth(), b.getHeight()) * 0.5f;
    auto cx = b.getCentreX(), cy = b.getCentreY();
    auto angle = startAngle + pos * (endAngle - startAngle);
    auto rInner = radius * 0.62f;

    g.setColour (juce::Colour (0xff10131c));
    g.fillEllipse (cx - rInner, cy - rInner, rInner * 2, rInner * 2);
    g.setColour (kEdge);
    g.drawEllipse (cx - rInner, cy - rInner, rInner * 2, rInner * 2, 1.2f);

    juce::Path track; track.addCentredArc (cx, cy, radius, radius, 0, startAngle, endAngle, true);
    g.setColour (kEdge); g.strokePath (track, juce::PathStrokeType (3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    juce::Path val; val.addCentredArc (cx, cy, radius, radius, 0, startAngle, angle, true);
    g.setColour (kTeal); g.strokePath (val, juce::PathStrokeType (3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    juce::Path ptr; auto pl = rInner * 0.9f;
    ptr.startNewSubPath (cx, cy);
    ptr.lineTo (cx + pl * std::cos (angle - juce::MathConstants<float>::halfPi),
                cy + pl * std::sin (angle - juce::MathConstants<float>::halfPi));
    g.setColour (kTeal); g.strokePath (ptr, juce::PathStrokeType (2.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
}

void LA1shotEditor::addKnob (const juce::String& id, const juce::String& name)
{
    auto* c = new Ctl();
    c->slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    c->slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 60, 15);
    c->slider.setColour (juce::Slider::textBoxTextColourId, kTeal);
    c->slider.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    c->slider.setLookAndFeel (&lnf);
    addAndMakeVisible (c->slider);
    c->label.setText (name, juce::dontSendNotification);
    c->label.setJustificationType (juce::Justification::centred);
    c->label.setColour (juce::Label::textColourId, kMuted);
    c->label.setFont (juce::Font (10.0f, juce::Font::bold));
    addAndMakeVisible (c->label);
    c->att = std::make_unique<SliderAtt> (proc.apvts, id, c->slider);
    knobs.add (c);
}

LA1shotEditor::LA1shotEditor (LA1shotProcessor& p) : AudioProcessorEditor (&p), proc (p)
{
    setLookAndFeel (&lnf);
    auto setupCombo = [this] (juce::ComboBox& box, const juce::StringArray& items) {
        box.addItemList (items, 1);
        box.setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff10131c));
        box.setColour (juce::ComboBox::textColourId, kTeal);
        box.setColour (juce::ComboBox::outlineColourId, kEdge);
        box.setColour (juce::ComboBox::arrowColourId, kTeal);
        box.setLookAndFeel (&lnf);
        addAndMakeVisible (box);
    };
    setupCombo (keyBox, { "C","C#","D","D#","E","F","F#","G","G#","A","A#","B" });
    setupCombo (scaleBox, { "Major", "Minor", "Chromatic" });
    keyAtt   = std::make_unique<ComboAtt> (proc.apvts, "key", keyBox);
    scaleAtt = std::make_unique<ComboAtt> (proc.apvts, "scale", scaleBox);

    addKnob ("tune", "TUNE");   addKnob ("speed", "SPEED");   // 0,1
    addKnob ("hp", "HP");       addKnob ("low", "LOW");        // 2,3
    addKnob ("mid", "MID");     addKnob ("high", "AIR");       // 4,5
    addKnob ("comp", "COMP");   addKnob ("deess", "DE-ESS");   // 6,7
    addKnob ("reverb", "VERB"); addKnob ("mix", "MIX");        // 8,9
    addKnob ("output", "OUT");                                 // 10

    startTimerHz (24);
    setSize (860, 470);
}

LA1shotEditor::~LA1shotEditor()
{
    for (auto* c : knobs) c->slider.setLookAndFeel (nullptr);
    keyBox.setLookAndFeel (nullptr); scaleBox.setLookAndFeel (nullptr);
    setLookAndFeel (nullptr);
}

void LA1shotEditor::timerCallback()
{
    meterHz = proc.detectedHz.load();
    meterTgt = proc.targetHz.load();
    repaint (rMeter);
}

static void panel (juce::Graphics& g, juce::Rectangle<int> r, const juce::String& t)
{
    auto rf = r.toFloat();
    g.setColour (kPanel); g.fillRoundedRectangle (rf, 10.0f);
    g.setColour (kEdge); g.drawRoundedRectangle (rf.reduced (0.5f), 10.0f, 1.0f);
    g.setColour (kViolet); g.setFont (juce::Font (10.0f, juce::Font::bold));
    g.drawText (t, r.getX() + 12, r.getY() + 7, r.getWidth() - 20, 12, juce::Justification::left);
}

void LA1shotEditor::paint (juce::Graphics& g)
{
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff141026), 0, 0, kBg, 0, (float) getHeight(), false));
    g.fillAll();
    auto chassis = getLocalBounds().reduced (7).toFloat();
    g.setColour (juce::Colour (0xff0e1018)); g.fillRoundedRectangle (chassis, 14.0f);
    g.setColour (kEdge); g.drawRoundedRectangle (chassis.reduced (0.5f), 14.0f, 1.2f);

    // title
    g.setColour (kText); g.setFont (juce::Font (22.0f, juce::Font::bold));
    g.drawText ("LA1shot", 34, 16, 300, 28, juce::Justification::left);
    g.setColour (kTeal); g.setFont (juce::Font (22.0f, juce::Font::bold));
    g.drawText ("LA", 34, 16, 40, 28, juce::Justification::left);
    g.setColour (kMuted); g.setFont (juce::Font (10.0f, juce::Font::bold));
    g.drawText ("AUTO-TUNE VOCAL CHAIN", getWidth() - 240, 22, 200, 16, juce::Justification::right);

    panel (g, rTune, "AUTO-TUNE");
    panel (g, rEq,   "EQ");
    panel (g, rDyn,  "DYNAMICS \xC2\xB7 FX");

    // pitch meter
    auto m = rMeter.toFloat();
    g.setColour (juce::Colour (0xff10131c)); g.fillRoundedRectangle (m, 8.0f);
    g.setColour (kEdge); g.drawRoundedRectangle (m.reduced (0.5f), 8.0f, 1.0f);
    g.setColour (kMuted); g.setFont (juce::Font (9.0f, juce::Font::bold));
    g.drawText ("PITCH", (int) m.getX() + 10, (int) m.getY() + 6, 80, 12, juce::Justification::left);
    auto noteName = [] (float hz) -> juce::String {
        if (hz < 40) return "--";
        static const char* nm[] = {"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
        int midi = (int) std::round (69.0 + 12.0 * std::log2 (hz / 440.0));
        return juce::String (nm[((midi % 12) + 12) % 12]) + juce::String (midi / 12 - 1);
    };
    g.setColour (kTeal); g.setFont (juce::Font (juce::Font::getDefaultMonospacedFontName(), 26.0f, juce::Font::bold));
    g.drawText (noteName (meterTgt), (int) m.getX(), (int) m.getY() + 20, (int) m.getWidth(), 34, juce::Justification::centred);
    g.setColour (kMuted); g.setFont (juce::Font (juce::Font::getDefaultMonospacedFontName(), 11.0f, juce::Font::plain));
    g.drawText (meterHz > 40 ? juce::String (meterHz, 1) + " Hz in" : "silent",
                (int) m.getX(), (int) m.getBottom() - 22, (int) m.getWidth(), 14, juce::Justification::centred);
}

void LA1shotEditor::resized()
{
    auto area = getLocalBounds().reduced (24);
    area.removeFromTop (44);

    auto top = area.removeFromTop (170);
    rTune = top.removeFromLeft (330);
    top.removeFromLeft (12);
    rMeter = top.removeFromRight (150);
    top.removeFromRight (12);
    rEq = top;

    area.removeFromTop (14);
    rDyn = area.removeFromTop (150);

    // Auto-tune panel: key + scale combos + tune/speed knobs
    auto tune = rTune.reduced (14); tune.removeFromTop (16);
    auto combos = tune.removeFromTop (30);
    keyBox.setBounds (combos.removeFromLeft (140).reduced (2));
    combos.removeFromLeft (8);
    scaleBox.setBounds (combos.removeFromLeft (140).reduced (2));
    tune.removeFromTop (10);
    auto layK = [] (Ctl* c, juce::Rectangle<int> cell) { c->label.setBounds (cell.removeFromTop (13)); c->slider.setBounds (cell.reduced (4)); };
    { auto row = tune; int cw = row.getWidth() / 2; layK (knobs[0], row.removeFromLeft (cw)); layK (knobs[1], row); }

    // EQ panel: hp, low, mid, air
    { auto e = rEq.reduced (14); e.removeFromTop (16); int cw = e.getWidth() / 4;
      layK (knobs[2], e.removeFromLeft (cw)); layK (knobs[3], e.removeFromLeft (cw));
      layK (knobs[4], e.removeFromLeft (cw)); layK (knobs[5], e); }

    // Dynamics/FX: comp, deess, verb, mix, out
    { auto dq = rDyn.reduced (14); dq.removeFromTop (16); int cw = dq.getWidth() / 5;
      layK (knobs[6], dq.removeFromLeft (cw)); layK (knobs[7], dq.removeFromLeft (cw));
      layK (knobs[8], dq.removeFromLeft (cw)); layK (knobs[9], dq.removeFromLeft (cw));
      layK (knobs[10], dq); }
}
