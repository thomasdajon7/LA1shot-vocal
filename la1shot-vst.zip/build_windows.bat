@echo off
REM ============================================================
REM  1o1 DARK SYNTH - Windows build script (VST3)
REM  Requirements:
REM    - Visual Studio 2022 (Desktop C++ workload)
REM    - CMake  (https://cmake.org/download/)
REM ============================================================
cd /d "%~dp0"

echo ==> Configuring (this downloads JUCE the first time)...
cmake -B build -G "Visual Studio 17 2022" -A x64
if errorlevel 1 goto :error

echo ==> Building Release...
cmake --build build --config Release
if errorlevel 1 goto :error

echo.
echo DONE. VST3 built at:
echo   build\1o1DarkSynth_artefacts\Release\VST3\1o1 DARK SYNTH.vst3
echo.
echo Copy that .vst3 folder to:  C:\Program Files\Common Files\VST3\
echo Then in FL Studio: Options ^> Manage Plugins ^> Find installed plugins.
goto :eof

:error
echo BUILD FAILED. Make sure Visual Studio 2022 (C++) and CMake are installed.
exit /b 1
