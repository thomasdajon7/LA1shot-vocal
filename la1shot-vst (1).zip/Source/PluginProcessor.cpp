#include "PluginProcessor.h"
#include "PluginEditor.h"

LA1shotProcessor::LA1shotProcessor()
    : AudioProcessor (BusesProperties()
        .withInput ("Input", juce::AudioChannelSet::stereo(), true)
        .withOutput ("Output", juce::AudioChannelSet::stereo(), true))
{
}

juce::AudioProcessorValueTreeState::ParameterLayout LA1shotProcessor::createLayout()
{
    using P = juce::AudioParameterFloat;
    using C = juce::AudioParameterChoice;
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;

    p.push_back (std::make_unique<C> ("key", "Key",
        juce::StringArray { "C","C#","D","D#","E","F","F#","G","G#","A","A#","B" }, 9)); // A
    p.push_back (std::make_unique<C> ("scale", "Scale",
        juce::StringArray { "Major", "Minor", "Chromatic" }, 1)); // Minor
    p.push_back (std::make_unique<P> ("tune", "Tune Amount", 0.0f, 1.0f, 0.85f));
    p.push_back (std::make_unique<P> ("speed", "Retune Speed", juce::NormalisableRange<float>(0.0f, 1.0f, 0.001f), 0.85f));

    p.push_back (std::make_unique<P> ("hp", "High Pass", juce::NormalisableRange<float>(20.0f, 400.0f, 1.0f, 0.4f), 80.0f));
    p.push_back (std::make_unique<P> ("low", "Low", juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f), 0.0f));
    p.push_back (std::make_unique<P> ("mid", "Mid", juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f), 0.0f));
    p.push_back (std::make_unique<P> ("high", "Air", juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f), 0.0f));

    p.push_back (std::make_unique<P> ("comp", "Compress", 0.0f, 1.0f, 0.35f));
    p.push_back (std::make_unique<P> ("deess", "De-Ess", 0.0f, 1.0f, 0.3f));
    p.push_back (std::make_unique<P> ("reverb", "Reverb", 0.0f, 1.0f, 0.2f));
    p.push_back (std::make_unique<P> ("mix", "Mix", 0.0f, 1.0f, 1.0f));
    p.push_back (std::make_unique<P> ("output", "Output", juce::NormalisableRange<float>(-24.0f, 12.0f, 0.1f), 0.0f));

    return { p.begin(), p.end() };
}

void LA1shotProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    sr = sampleRate;
    juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) samplesPerBlock, 2 };

    hp.prepare (spec); eqLow.prepare (spec); eqMid.prepare (spec); eqHigh.prepare (spec);
    deEssShelf.prepare (spec);
    comp.prepare (spec); comp.setAttack (2.0f); comp.setRelease (120.0f);
    reverb.prepare (spec);

    for (int ch = 0; ch < 2; ++ch)
    {
        deEssDetect[ch].prepare (spec);
        deEssDetect[ch].coefficients = Coefs::makeHighPass (sampleRate, 6000.0f);
        deEssDetect[ch].reset();
        deEssEnv[ch] = 0.0f;
    }

    pitchBufLen = juce::nextPowerOfTwo ((int) (sampleRate * 0.05)); // ~50ms
    pitchBuf.assign ((size_t) pitchBufLen, 0.0f);
    pitchWrite = 0;

    dlLen = juce::nextPowerOfTwo ((int) (sampleRate * 0.08));
    for (int ch = 0; ch < 2; ++ch)
    {
        shifter[ch].dl.assign ((size_t) dlLen, 0.0f);
        shifter[ch].wr = 0;
        shifter[ch].rp1 = 0.0f;
        shifter[ch].rp2 = (float) dlLen * 0.5f;
    }
    smoothedRatio = 1.0f;
}

bool LA1shotProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in  = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    if (in != out) return false;
    return in == juce::AudioChannelSet::mono() || in == juce::AudioChannelSet::stereo();
}

float LA1shotProcessor::scaleQuantise (float hz) const
{
    if (hz < 40.0f || hz > 2000.0f) return hz;
    const int key = (int) *apvts.getRawParameterValue ("key");
    const int scaleType = (int) *apvts.getRawParameterValue ("scale");

    // scale intervals (semitones from root)
    static const int major[] = { 0,2,4,5,7,9,11 };
    static const int minor[] = { 0,2,3,5,7,8,10 };
    const int* sc = scaleType == 0 ? major : minor;
    const int scN = 7;

    float midi = 69.0f + 12.0f * std::log2 (hz / 440.0f);
    int nearest = (int) std::round (midi);

    if (scaleType != 2) // not chromatic — snap to scale degree
    {
        int best = nearest; float bestDist = 1e9f;
        for (int oct = -1; oct <= 1; ++oct)
            for (int i = 0; i < scN; ++i)
            {
                int cand = key + sc[i] + 12 * ((nearest / 12) + oct);
                float dist = std::abs ((float) cand - midi);
                if (dist < bestDist) { bestDist = dist; best = cand; }
            }
        nearest = best;
    }
    return 440.0f * std::pow (2.0f, (nearest - 69.0f) / 12.0f);
}

void LA1shotProcessor::detectPitch()
{
    // Autocorrelation over the ring buffer (copy to linear window)
    const int N = pitchBufLen;
    std::vector<float> w ((size_t) N);
    for (int i = 0; i < N; ++i) w[(size_t) i] = pitchBuf[(size_t) ((pitchWrite + i) % N)];

    const int minLag = (int) (sr / 1000.0); // 1000 Hz
    const int maxLag = (int) (sr / 70.0);   // 70 Hz
    float bestCorr = 0.0f; int bestLag = 0;
    float energy = 0.0f;
    for (int i = 0; i < N; ++i) energy += w[(size_t) i] * w[(size_t) i];
    if (energy < 1e-4f) { detectedHz = 0.0f; return; }

    for (int lag = minLag; lag <= maxLag && lag < N; ++lag)
    {
        float c = 0.0f;
        for (int i = 0; i + lag < N; ++i) c += w[(size_t) i] * w[(size_t) (i + lag)];
        if (c > bestCorr) { bestCorr = c; bestLag = lag; }
    }
    detectedHz = bestLag > 0 ? (float) (sr / bestLag) : 0.0f;
}

void LA1shotProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int n = buffer.getNumSamples();
    const int nch = buffer.getNumChannels();

    // keep a clean dry copy for the global Mix blend
    juce::AudioBuffer<float> dryBuf;
    dryBuf.makeCopyOf (buffer);

    // feed the detection ring from ch0
    if (nch > 0)
    {
        auto* in0 = buffer.getReadPointer (0);
        for (int i = 0; i < n; ++i) { pitchBuf[(size_t) pitchWrite] = in0[i]; pitchWrite = (pitchWrite + 1) % pitchBufLen; }
    }
    detectPitch();

    const float tuneAmt = *apvts.getRawParameterValue ("tune");
    const float speed   = *apvts.getRawParameterValue ("speed");
    float det = detectedHz.load();
    float ratio = 1.0f;
    if (det > 40.0f)
    {
        float tgt = scaleQuantise (det);
        targetHz = tgt;
        ratio = juce::jlimit (0.5f, 2.0f, tgt / det);
    }
    // retune speed -> smoothing coefficient (fast when speed high)
    const float sm = 1.0f - std::pow (0.0005f, (0.02f + speed * 0.98f));
    smoothedRatio += sm * (ratio - smoothedRatio);
    const float effRatio = 1.0f + (smoothedRatio - 1.0f) * tuneAmt;

    // ---- Auto-Tune granular pitch shift (per channel) ----
    const float win = (float) dlLen * 0.5f;
    for (int ch = 0; ch < nch && ch < 2; ++ch)
    {
        auto& S = shifter[ch];
        auto* d = buffer.getWritePointer (ch);
        for (int i = 0; i < n; ++i)
        {
            const float dryS = d[i];
            S.dl[(size_t) S.wr] = dryS;

            auto readAt = [&] (float pos) {
                int i0 = (int) pos; float fr = pos - i0;
                int a = ((S.wr - i0) % dlLen + dlLen) % dlLen;
                int b = ((a - 1) % dlLen + dlLen) % dlLen;
                return S.dl[(size_t) a] * (1.0f - fr) + S.dl[(size_t) b] * fr;
            };
            float g1 = readAt (S.rp1);
            float g2 = readAt (S.rp2);
            // triangular crossfade based on rp1 position through the window
            float x = S.rp1 / win; if (x > 1.0f) x -= 1.0f;
            float w1 = 1.0f - std::abs (2.0f * x - 1.0f);
            float w2 = 1.0f - w1;
            float wet = g1 * w1 + g2 * w2;

            // blend so Tune=0 is fully clean/dry (never silent)
            d[i] = dryS * (1.0f - tuneAmt) + wet * tuneAmt;

            S.rp1 += (1.0f - effRatio); if (S.rp1 < 0) S.rp1 += win; if (S.rp1 >= win) S.rp1 -= win;
            S.rp2 = S.rp1 + win * 0.5f; if (S.rp2 >= win) S.rp2 -= win;
            S.wr = (S.wr + 1) % dlLen;
        }
    }

    juce::dsp::AudioBlock<float> block (buffer);

    // HPF
    hp.state = *Coefs::makeHighPass (sr, *apvts.getRawParameterValue ("hp"));
    // EQ
    eqLow.state  = *Coefs::makeLowShelf  (sr, 180.0f, 0.7f, juce::Decibels::decibelsToGain ((float) *apvts.getRawParameterValue ("low")));
    eqMid.state  = *Coefs::makePeakFilter (sr, 1500.0f, 0.8f, juce::Decibels::decibelsToGain ((float) *apvts.getRawParameterValue ("mid")));
    eqHigh.state = *Coefs::makeHighShelf (sr, 8000.0f, 0.7f, juce::Decibels::decibelsToGain ((float) *apvts.getRawParameterValue ("high")));

    juce::dsp::ProcessContextReplacing<float> ctx (block);
    hp.process (ctx); eqLow.process (ctx); eqMid.process (ctx); eqHigh.process (ctx);

    // Compressor
    const float cAmt = *apvts.getRawParameterValue ("comp");
    comp.setThreshold (-6.0f - cAmt * 24.0f);
    comp.setRatio (1.0f + cAmt * 7.0f);
    comp.process (ctx);
    if (cAmt > 0.0f) block.multiplyBy (juce::Decibels::decibelsToGain (cAmt * 6.0f)); // makeup

    // De-Esser (dynamic high-shelf reduction from sibilant sidechain)
    const float deAmt = *apvts.getRawParameterValue ("deess");
    float maxRed = 0.0f;
    for (int ch = 0; ch < nch && ch < 2; ++ch)
    {
        auto* d = buffer.getWritePointer (ch);
        for (int i = 0; i < n; ++i)
        {
            float s = deEssDetect[ch].processSample (d[i]);
            float a = std::abs (s);
            deEssEnv[ch] += (a > deEssEnv[ch] ? 0.3f : 0.02f) * (a - deEssEnv[ch]);
        }
        maxRed = juce::jmax (maxRed, deEssEnv[ch]);
    }
    float reductionDb = -juce::jmin (12.0f, maxRed * 60.0f * deAmt);
    deEssShelf.state = *Coefs::makeHighShelf (sr, 6500.0f, 0.7f, juce::Decibels::decibelsToGain (reductionDb));
    deEssShelf.process (ctx);

    // Reverb
    const float rvb = *apvts.getRawParameterValue ("reverb");
    juce::Reverb::Parameters rp; rp.roomSize = 0.6f; rp.damping = 0.5f; rp.width = 1.0f;
    rp.wetLevel = rvb * 0.6f; rp.dryLevel = 1.0f; reverb.setParameters (rp);
    reverb.process (ctx);

    // Global dry/wet mix (Mix=1 fully processed, Mix=0 clean input)
    const float mix = *apvts.getRawParameterValue ("mix");
    if (mix < 0.999f)
        for (int ch = 0; ch < nch; ++ch)
        {
            auto* d = buffer.getWritePointer (ch);
            auto* dry = dryBuf.getReadPointer (juce::jmin (ch, dryBuf.getNumChannels() - 1));
            for (int i = 0; i < n; ++i) d[i] = d[i] * mix + dry[i] * (1.0f - mix);
        }

    // Output gain
    block.multiplyBy (juce::Decibels::decibelsToGain ((float) *apvts.getRawParameterValue ("output")));
}

juce::AudioProcessorEditor* LA1shotProcessor::createEditor() { return new LA1shotEditor (*this); }

void LA1shotProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto s = apvts.copyState().createXml()) copyXmlToBinary (*s, destData);
}
void LA1shotProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes)) apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new LA1shotProcessor(); }
